﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CoordonneeGPS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordonneeGPS.Tests
{
    [TestClass()]
    public class CoordonneeTests
    {
        /// <summary>
        /// methode de test pour les coordonnées.
        /// </summary>
        [TestMethod()]
        public void CoordonneeTest()
        {
            //arranger
            double latitude = 2;
            double longitude = 4;
            // agir
            Coordonnee coordonnee = new Coordonnee(latitude, longitude);

            /// arranger et agir et affirmer
            Assert.AreEqual(latitude * longitude, coordonnee.CalculerAire(latitude,longitude), "Lair n'est pas bon");
            Assert.AreEqual(latitude, coordonnee.CoordonneeGPSLatitude, "la latitude ne ses pas correctement initialiser");
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => new Coordonnee(-1000, 0), "exception non levé");
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => new Coordonnee(1000, 0), "exception non levé");



        }
    }
}