﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace CoordonneeGPS
{
    /// <summary>
    /// Assume un champ de4 type carré ou rectagulaire
    /// </summary>
    public class Champ
    {
        private int _longueueEnPied;
        private int _largeurEnPied;
        private double _coordonneeGPSLatitude;
        private double _coordonneeGPSLongitude;
        private Coordonnee _coordonnee;

        public int LongueueEnPied
        {
            get => _longueueEnPied;
        }
        public int LargeurEnPied
        {
            get => _largeurEnPied;
        }
        public double CoordonneeGPSLatitude
        {
            get => _coordonneeGPSLatitude;
        }
        public double CoordonneeGPSLongitude
        {
            get => _coordonneeGPSLongitude;
        }
        public Coordonnee Coordonnee
        {
            get => _coordonnee;
        }

        /// <summary>
        /// constructeur  d'un champs non mesuré, on ne connais que la coordonnée Gps
        /// </summary>
        /// <param name="coordonneeGPSLatitude">Latitude selon le système degrée décimal</param>
        /// <param name="coordonneeGPSLongitude">Longitude selon le système degrée décimal</param>

        public Champ(double coordonneeGPSLatitude, double coordonneeGPSLongitude)
        {

            _coordonneeGPSLatitude = coordonneeGPSLatitude;
            _coordonneeGPSLongitude = coordonneeGPSLongitude;
        }
        /// <summary>
        /// constructeur qui initialise tout les champ;
        /// </summary>
        /// <param name="longueueEnPied">Longueur du champ sur l'axe nord sud</param>
        /// <param name="largeurEnPied">Largeur du champ sur l'axe est ouest </param>
        /// <param name="coordonneeGPSLatitude">Latitude selon le système degrée décimal</param>
        /// <param name="coordonneeGPSLongitude">Longitude selon le système degrée décimal</param>
        public Champ(int longueueEnPied, int largeurEnPied, double coordonneeGPSLatitude, double coordonneeGPSLongitude) : this(coordonneeGPSLatitude, coordonneeGPSLongitude)
        {
            _longueueEnPied = longueueEnPied;
            _largeurEnPied = largeurEnPied;
            _coordonneeGPSLatitude = coordonneeGPSLatitude;
            _coordonneeGPSLongitude = coordonneeGPSLongitude;
        }
        /// <summary>
        /// constructeur qui initialise les coordonnée du champ
        /// </summary>
        /// <param name="coordonnee">Latitude et Longitude selon le système degrée décimal</param>
        public Champ(Coordonnee coordonnee)
        {
            _coordonnee = coordonnee;
        }
        /// <summary>
        /// constructeur qui initialise tout les champ
        /// </summary>
        /// <param name="coordonnee">>Latitude et Longitude selon le système degrée décimal</param>
        /// <param name="longueueEnPied">Longueur du champ sur l'axe nord sud</param>
        /// <param name="largeurEnPied">Largeur du champ sur l'axe est ouest</param>
        public Champ(Coordonnee coordonnee, int longueueEnPied, int largeurEnPied) : this(coordonnee)
        {
            _longueueEnPied = longueueEnPied;
            _largeurEnPied = largeurEnPied;
        }
    }
}
