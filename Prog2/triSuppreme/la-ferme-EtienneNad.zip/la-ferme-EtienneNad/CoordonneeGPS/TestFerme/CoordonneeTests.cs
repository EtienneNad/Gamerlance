﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CoordonneeGPS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CoordonneeGPS.Tests
{
    [TestClass()]
    public class CoordonneeTests
    {
        [TestMethod()]
        public void CoordonneeTest()
        {
            int largeur = 2;
            int longueur = 4;
            ///arranger
            Coordonnee gps = new Coordonnee(largeur, longueur);
        }

        
       
    }
}