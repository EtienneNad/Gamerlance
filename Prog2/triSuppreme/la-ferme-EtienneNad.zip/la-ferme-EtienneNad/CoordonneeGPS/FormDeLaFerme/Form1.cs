namespace FormDeLaFerme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            MouseEventArgs me = (MouseEventArgs)e;
            if (e.GetType() == typeof(MouseEventArgs))
            {
                Graphics laToile = this.CreateGraphics();
                if (me.Button == MouseButtons.Left)
                {
                    Pen pencil = new Pen(new SolidBrush(Color.Brown), 5);
                    laToile.DrawEllipse(pencil, e.X, e.Y, 10, 10);
                    laToile.DrawString("Hello", new Font("Arial", 20), new SolidBrush(Color.Green), 6, 9);
                }

                if (me.Button == MouseButtons.Right)
                {
                    Pen pencil = new Pen(new SolidBrush(Color.Blue), 5);
                    laToile.DrawRectangle(pencil, e.X, e.Y, 10, 10);
                    laToile.DrawString("poop", new Font("Arial", 20), new SolidBrush(Color.Brown), 6, 9);
                }
            }
        }
    }
}