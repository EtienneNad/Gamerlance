﻿using System;

namespace auto
{
    public class Class1
    {
    }
}
