﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordonneeGPS
{
   
    public class Ferme
    {
        List<Champ> lesChamps = new List<Champ>();
        /// <summary>
        /// Constructeur par défaut avec un champs non dimetionnée en coordonée 0,0.
        /// </summary>
        public Ferme()
        {
            
            Champ champs = new Champ(0, 0);
            lesChamps.Add(champs);
        }
    }
}
