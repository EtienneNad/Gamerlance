﻿namespace CoordonneeGPS
{
    /// <summary>
    /// Assume un champ de4 type carré ou rectagulaire
    /// </summary>
    public class Coordonnee : ICalculerAire
    {
        private double _coordonneeGPSLatitude;
        private double _coordonneeGPSLongitude;

        public double CoordonneeGPSLatitude
        {
            get => _coordonneeGPSLatitude;
        }
        public double CoordonneeGPSLongitude
        {
            get => _coordonneeGPSLongitude;
        }

        /// <summary>
        /// constructeur  d'un champs non mesuré, on ne connais que la coordonnée Gps
        /// </summary>
        /// <param name="coordonneeGPSLatitude">Latitude selon le système degrée décimal</param>
        /// <param name="coordonneeGPSLongitude">Longitude selon le système degrée décimal</param>

        public Coordonnee(double coordonneeGPSLatitude, double coordonneeGPSLongitude)
        {
            ValiderCoordonnee(coordonneeGPSLatitude, coordonneeGPSLongitude);

            _coordonneeGPSLatitude = coordonneeGPSLatitude;
            _coordonneeGPSLongitude = coordonneeGPSLongitude;
        }
        /// <summary>
        /// Lance une exception si la coordonnée n'est pas valide en latitude et en  longitude
        /// </summary>
        /// <param name="coordonneeGPSLatitude">Latitude selon le système degrée décimal</param>
        /// <param name="coordonneeGPSLongitude">Longitude selon le système degrée décimal</param>
        private void ValiderCoordonnee(double coordonneeGPSLatitude, double coordonneeGPSLongitude)
        {
            ValiderLatitude(coordonneeGPSLatitude);
            ValiderLongitude(coordonneeGPSLongitude);
        }

        /// <summary>
        ///  Lance une exception si la coordonnée n'est pas valide en longitude
        /// </summary>
        /// <param name="coordonneeGPSLongitude">Longitude selon le système degrée décimal</param>
        /// <exception cref="ArgumentOutOfRangeException">Si la coordonnée est hors plage en longitude</exception>
        private void ValiderLongitude(double coordonneeGPSLongitude)
        {
            if (coordonneeGPSLongitude < -180 || coordonneeGPSLongitude > 180)
            {
                throw new ArgumentOutOfRangeException("La longitude n'est pas valide[-180,+180]");
            }

        }


        /// <summary>
        ///  Lance une exception si la coordonnée n'est pas valide en latitude
        /// </summary>
        /// <param name="coordonneeGPSLatitude">Latitude selon le système degrée décimal</param>
        /// <exception cref="ArgumentOutOfRangeException">Si la coordonnée est hors plage en latitude</exception>
        private void ValiderLatitude(double coordonneeGPSLatitude)
        {
            if (coordonneeGPSLatitude < -90 || coordonneeGPSLatitude > 90)
            {
                throw new ArgumentOutOfRangeException("La Latitude n'est pas valide[-90,+90]");
            }
        }

        public double CalculerAire(double coordonneeGPSLatitude, double coordonneeGPSLongitude)
        {
            return coordonneeGPSLatitude * coordonneeGPSLongitude;
        }
    }
}