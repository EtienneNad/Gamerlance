﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cours1_exercices7
{
    class Program
    {

        static void Main()
        {
            
           
            int val = 3;
           
            for (int i = 0; i < val; i++)
            {
             
                Console.WriteLine("*");
            }

            Console.ReadLine();

        }
    }
}
