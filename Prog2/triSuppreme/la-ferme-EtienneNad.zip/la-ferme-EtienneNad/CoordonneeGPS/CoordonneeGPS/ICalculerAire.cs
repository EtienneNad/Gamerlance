﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoordonneeGPS
{
    public interface ICalculerAire
    {
         double Aire(double coordonneeGPSLatitude,double coordonneeGPSLongitude)
        {
            return coordonneeGPSLatitude * coordonneeGPSLongitude;
        }
    }
}
